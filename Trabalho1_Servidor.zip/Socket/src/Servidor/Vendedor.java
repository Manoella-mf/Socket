/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Servidor;

/**
 *
 * @author 10771894945
 */
public class Vendedor extends Pessoa {
    private double comissao;

    public Vendedor(String cpf, String nome, String endereco) {
        super(cpf, nome, endereco);
    }
    
    public boolean isVendedor(String cpf) {
        return cpf.equals(super.getCpf());
    }

    public double getComissao() {
        return comissao;
    }

    public void calcularComissao(double valorVenda) {
        this.comissao += valorVenda * 0.1;
    }

    @Override
    public String toString() {
        return super.toString() + ", Vendedor{comissao=" + comissao + "}";
    }
}