/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Servidor;

import java.util.List;

/**
 *
 * @author 10771894945
 */
class Produto {
    private int idProduto;
    private String descricao;
    private double valor;
    private String vendedorCPF; 

    public Produto(int idProduto, String descricao, double valor, String cpf) {
        this.idProduto = idProduto;
        this.descricao = descricao;
        this.valor = valor;
        this.vendedorCPF = cpf;
    }

    public int getIdProduto() {
        return idProduto;
    }
    
     public String getVendedorCPF() {
        return vendedorCPF;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }
    
    public boolean remover(List<Produto> listaProdutos, int idProduto) {
        return listaProdutos.removeIf(p -> p.getIdProduto()== idProduto);
    }

    @Override
    public String toString() {
        return idProduto + ";" + descricao + ";" + valor;
    }
}