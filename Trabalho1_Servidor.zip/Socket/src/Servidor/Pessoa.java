/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Servidor;

import java.util.Iterator;
import java.util.List;

/**
 *
 * @author 10771894945
 */
class Pessoa {
    private String cpf, nome, endereco;

    public Pessoa(String cpf, String nome, String endereco) {
        this.cpf = cpf;
        this.nome = nome;
        this.endereco = endereco;
    }

    public String getCpf() {
        return cpf;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }
    
    public boolean remover(List<Pessoa> listaPessoas, String cpf) {
        Iterator<Pessoa> iterator = listaPessoas.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().getCpf().equals(cpf)) {
                iterator.remove();
                return true;
            }
        }
        return false;
    }

    @Override
    public String toString() {
        return cpf + ";" + nome + ";" + endereco;
    }
}