package Servidor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dudaj
 */
public class Server {
    private static List<Pessoa> pessoas = new ArrayList<>();
    private static List<Cliente> clientes = new ArrayList<>();
    private static List<Vendedor> vendedores = new ArrayList<>();
    private static List<Pedido> pedidos = new ArrayList<>();
    private static List<Produto> produtos = new ArrayList<>();
    private static AtomicInteger pedidoIdGenerator = new AtomicInteger(1);

    public static void main(String[] args) throws IOException {
        ServerSocket server = new ServerSocket(12345);
        System.out.println("Servidor iniciado. Aguardando conexões...");

        while (true) { 
            try (Socket conn = server.accept();
                 BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                 PrintWriter writer = new PrintWriter(conn.getOutputStream(), true)) {

                System.out.println("Cliente conectado: " + conn.getInetAddress().getHostAddress());
                
                String mensagemRecebida = reader.readLine();
                if (mensagemRecebida == null) continue;

                System.out.println("Mensagem recebida: " + mensagemRecebida);
                String[] partes = mensagemRecebida.split(";");

                if (partes.length == 0) {
                    writer.println("Erro: Nenhuma operação informada.");
                    continue;
                }
                String operacao = partes[0].toUpperCase();
                System.out.println(operacao);

                switch (operacao) {
                    case "INSERT":
                        
                        if (partes.length < 5) {
                            writer.println("Erro: Dados insuficientes.");
                            break;
                        }
                        Pessoa novaPessoa = new Pessoa(partes[1], partes[2], partes[3]);
                        pessoas.add(novaPessoa);

                        String tipo = partes[4];
                        if (tipo.equalsIgnoreCase("Cliente")) {
                            clientes.add(new Cliente(partes[1], partes[2], partes[3]));
                            writer.println("Cliente cadastrado com sucesso.");
                        } else if (tipo.equalsIgnoreCase("Vendedor")) {
                            vendedores.add(new Vendedor(partes[1], partes[2], partes[3]));
                            writer.println("Vendedor cadastrado com sucesso.");
                        } else {
                            writer.println("Erro: Tipo inválido. Cadastro finalizado apenas como Pessoa.");
                        }
                        break;

                    case "GET":
                        if (partes.length < 2) {
                            writer.println("Erro: CPF não informado.");
                            break;
                        }

                        String cpfBuscado = partes[1];
                        Pessoa encontrada = null;
                        if (pessoas.isEmpty()) {
                                writer.println("Sem pessoas cadastradas");
                        }else {
                            for (Pessoa p : pessoas) {
                                if (p.getCpf().equals(cpfBuscado)) {
                                    encontrada = p;
                                    break;
                                }
                            }
                        }
                        writer.println(encontrada != null ? encontrada : "Pessoa não encontrada.");
                        break;

                    case "UPDATE":
                        if (partes.length < 4) {
                            writer.println("Erro: Dados insuficientes para atualização.");
                            break;
                        }
                        Pessoa pessoaParaAtualizar = buscarPessoaPorCPF(partes[1]);
                        if (pessoaParaAtualizar != null) {
                            pessoaParaAtualizar.setNome(partes[2]);
                            pessoaParaAtualizar.setEndereco(partes[3]);
                            writer.println("Pessoa atualizada com sucesso.");
                        } else {
                            writer.println("Pessoa não encontrada.");
                        }
                        break;
                        
                    case "DELETE":
                        String cpf = partes[1];
                        if (pessoas.isEmpty()){
                            writer.println("Sem pessoas cadastradas");
                        }else 
                            for (Pessoa p : pessoas) {
                                if (p.remover(pessoas, cpf)) {
                                    writer.println("Pessoa removida com sucesso");
                                } else {
                                    writer.println("Pessoa não encontrada");
                                }
                            }
                        break;
                   
                    case "LIST":
                        if (pessoas.isEmpty()) {
                            writer.println("0");
                        } else {
                            writer.println(pessoas.size());
                            writer.flush();
                            for (Pessoa pessoa : pessoas) {
                                writer.println(pessoa.toString());
                                writer.flush();
                            }
                        }
                        break;
                        
                    case "INSERT_PEDIDO":
                        if (isCliente(reader, writer, partes[1])){
                            processarPedido(operacao, partes, writer);
                            break;
                        }else{
                            writer.println("Somente clientes podem realizar essa ação.");
                        }                           
                        break;

                    case "UPDATE_PEDIDO":
                        if (isCliente(reader, writer, partes[1])){
                            processarPedido(operacao, partes, writer);
                            break;
                        }else{
                            writer.println("Somente clientes podem realizar essa ação.");
                        }                           
                        break;
                        
                    case "GET_PEDIDO":
                        processarPedido(operacao, partes, writer);
                        break;
                        
                    case "DELETE_PEDIDO":
                        if (isCliente(reader, writer, partes[1])){
                            processarPedido(operacao, partes, writer);
                            break;
                        }else{
                            writer.println("Somente clientes podem realizar essa ação.");
                        }                           
                        break;
                    case "LIST_PEDIDO":
                        if (pedidos.isEmpty()) {
                            writer.println("0");
                        } else {
                            writer.println(pedidos.size());
                            writer.flush();
                            for (Pedido pedido : pedidos) {
                                writer.println(pedido.toString());
                                writer.flush();
                            }
                        }
                        break;
                    case "INSERT_PRODUTO":
                        if (isVendedor(partes[1])){
                            processarProduto(operacao, partes, writer);
                            break;
                        }else{
                            writer.println("Somente vendedores podem realizar essa ação.");
                        }
                        break;
                        
                    case "UPDATE_PRODUTO":
                        if (isVendedor(partes[1])){
                            processarProduto(operacao, partes, writer);
                            break;
                        }else{
                            writer.println("Somente vendedores podem realizar essa ação.");
                        }
                        break;
                        
                    case "GET_PRODUTO":
                        if (isVendedor(partes[1])){
                            processarProduto(operacao, partes, writer);
                            break;
                        }else{
                            writer.println("Somente vendedores podem realizar essa ação.");
                        }
                        break;
                        
                    case "DELETE_PRODUTO":
                        if (isVendedor(partes[1])){
                            processarProduto(operacao, partes, writer);
                            break;
                        }else{
                            writer.println("Somente vendedores podem realizar essa ação.");
                        }
                        break;
                        
                    case "LIST_PRODUTO":
                        if (produtos.isEmpty()) {
                            writer.println("0");
                        } else {
                            writer.println(produtos.size());
                            writer.flush();
                            for (Produto produto : produtos) {
                                writer.println(produto.toString());
                                writer.flush();
                            }
                        }
                        break;

                    default:
                        writer.println("Operação inválida");
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    private static Pessoa buscarPessoaPorCPF(String cpf) {
        for (Pessoa p : pessoas) {
            if (p.getCpf().equals(cpf)) return p;
        }
        return null;
    }

    private static List<Pedido> buscarPedidos(String cpf) {
        List<Pedido> pedidosDoCliente = new ArrayList<>();
        for (Pedido p : pedidos) {
            if (p.getCpfCliente().equals(cpf)) {
                pedidosDoCliente.add(p);
            }
        }
        return pedidosDoCliente;
    }

    private static Produto buscarProdutoPorDescricao(String descricao) {
        for (Produto p : produtos) {
            if (p.getDescricao().equalsIgnoreCase(descricao)) return p;
        }
        return null;
    }
    private static Produto buscarProdutoPorID(int id) {
        for (Produto p : produtos) {
            if (p.getIdProduto() == id) return p;
        }
        return null;
    }
    
    private static boolean isVendedor(String cpf) throws IOException {
        for (Vendedor vendedor : vendedores) {
             if (vendedor.getCpf().equals(cpf)) {
                 return true;
             }
         }
         return false;
     }

    private static boolean isCliente(BufferedReader reader, PrintWriter writer, String cpf) throws IOException {
         for (Cliente cliente : clientes) {
             if (cliente.getCpf().equals(cpf)) {
                 return true;
             }
         }
         return false;
    }

    private static void processarProduto(String operacao, String[] partes, PrintWriter writer) {
        switch (operacao) {
            case "INSERT_PRODUTO":
                if (partes.length < 5) {
                    writer.println("Erro: Dados insuficientes.");
                    break;
                }
                produtos.add(new Produto(Integer.parseInt(partes[2]), partes[3], Double.parseDouble(partes[4]),partes[1]));
                writer.println("Produto cadastrado com sucesso.");
                break;

            case "GET_PRODUTO":
                if (produtos.isEmpty()) {
                        writer.println("Sem produtos cadastrados");
                }else {
                    for (Produto pro : produtos) {
                        Produto produto = buscarProdutoPorID(Integer.parseInt(partes[1]));
                        writer.println(produto != null ? produto : "Produto não encontrado.");
                        break;
                    }
                }          
                break;

            case "UPDATE_PRODUTO":
                Produto p = buscarProdutoPorID(Integer.parseInt(partes[2]));
                if (p != null) {
                    p.setDescricao(partes[3]);
                    p.setValor(Double.parseDouble(partes[4]));
                    writer.println("Produto atualizado.");
                } else {
                    writer.println("Produto não encontrado.");
                }
                break;
            case "DELETE_PRODUTO":
                    int id = Integer.parseInt(partes[1]);
                    for (Produto pro : produtos) {
                        if (produtos.isEmpty()){
                            writer.println("Sem produtos cadastrados");
                        }else if (pro.remover(produtos, id)) {
                            writer.println("Produto removido com sucesso");
                        } else {
                            writer.println("Produto não encontrado");
                        }
                    }
                    break;
        }
    }

    private static void processarPedido(String operacao, String[] partes, PrintWriter writer) {
        switch (operacao) {
            case "INSERT_PEDIDO":
                double valorTotal = 0;
                String cpfVendedor = "";
                if (partes.length < 1) {
                    writer.println("Erro: Dados insuficientes.");
                    break;
                }
                Pedido pedido = new Pedido(pedidos.size() + 1, buscarPessoaPorCPF(partes[1]), partes[1]);
                for (int i = 2; i < partes.length; i++) {
                    Produto produto = buscarProdutoPorDescricao(partes[i]);
                    cpfVendedor = produto.getVendedorCPF();
                    valorTotal += produto.getValor();
                    if (produto != null) pedido.adicionarProduto(produto);
                }
                pedidos.add(pedido);
                for (Vendedor vendedor : vendedores) {
                    if(vendedor.getCpf().equals(cpfVendedor)){
                        vendedor.calcularComissao(valorTotal);
                    }
                }
                String cpfCliente = partes[1];
                for (Cliente cliente : clientes) {
                    if(cliente.getCpf().equals(cpfCliente)){
                        cliente.adicionarPontos(1);
                    }
                }
                writer.println("Pedido cadastrado com sucesso.");
                break;

            case "GET_PEDIDO":
                List<Pedido> pedidosDoCliente = buscarPedidos(partes[1]);
                
                if (pedidosDoCliente.isEmpty()) {
                    writer.println("0");
                } else {
                    writer.println(pedidosDoCliente.size());
                    for (Pedido p : pedidosDoCliente) {
                        writer.println(p.toString());
                        writer.flush();
                    }
                }
                break;
        }
    }
}