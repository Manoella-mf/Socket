/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Servidor;

/**
 *
 * @author 10771894945
 */
public class Cliente extends Pessoa {
    private int pontosFidelidade;

    public Cliente(String cpf, String nome, String endereco) {
        super(cpf, nome, endereco);
    }

    public int getPontosFidelidade() {
        return pontosFidelidade;
    }

    public void adicionarPontos(int pontos) {
        this.pontosFidelidade += pontos;
    }

    @Override
    public String toString() {
        return super.toString() + ", Cliente{pontosFidelidade=" + pontosFidelidade + "}";
    }
}
