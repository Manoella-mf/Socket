/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Servidor;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 10771894945
 */
class Pedido {
    private int idPedido;
    private Pessoa pessoa;
    private List<Produto> produtos;
    private double valorTotal;
    private String cpfCliente;

    public Pedido(int idPedido, Pessoa pessoa, String cpfCliente) {
        this.idPedido = idPedido;
        this.pessoa = pessoa;
        this.produtos = new ArrayList<>();
        this.valorTotal = 0.0;
        this.cpfCliente = cpfCliente;
    }

    public int getIdPedido() {
        return idPedido;
    }
    
    public String getCpfCliente(){
        return cpfCliente;
    }

    public void adicionarProduto(Produto produto) {
        produtos.add(produto);
        valorTotal += produto.getValor();
    }

    public static boolean remover(List<Pedido> listaPedidos, int idPedido) {
        return listaPedidos.removeIf(p -> p.getIdPedido()== idPedido);
    }
    
    @Override
    public String toString() {
        return pessoa + ";" + produtos + ";" + valorTotal;
    }
}