package Cliente;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
/**
 *
 * @author 10771894945
 */
public class Client {
    private static final String SERVER_IP = "127.0.0.1";
    private static final int SERVER_PORT = 12345;

    public static void main(String[] args) throws IOException {
        BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));

        while (true) {
            System.out.println("Escolha o que você quer acessar: Pessoa, Pedido ou Produto.");
            String opcao = teclado.readLine().toUpperCase();

            
            switch(opcao){
                case "PESSOA":
                    System.out.println("Digite a operação (INSERT, UPDATE, GET, LIST, DELETE, EXIT):");
                    String operacao = teclado.readLine();
                    if (operacao.equalsIgnoreCase("EXIT")) {
                        System.out.println("Encerrando cliente...");
                        break;
                    }
                    processarPessoa(operacao);
                    break;
                
                case "PEDIDO":
                    System.out.println("Digite a operação (INSERT_PEDIDO, GET_PEDIDO, LIST_PEDIDO, EXIT):");
                    operacao = teclado.readLine();
                    if (operacao.equalsIgnoreCase("EXIT")) {
                        System.out.println("Encerrando cliente...");
                        break;
                    }
                    processarPedido(operacao);
                    break;
                
                case "PRODUTO":
                    System.out.println("Digite a operação (INSERT_PRODUTO, UPDATE_PRODUTO, GET_PRODUTO, LIST_PRODUTO, DELETE_PRODUTO, EXIT):");
                    operacao = teclado.readLine();
                    if (operacao.equalsIgnoreCase("EXIT")) {
                        System.out.println("Encerrando cliente...");
                        break;
                    }
                    processarProduto(operacao);
                    break;
            }
        }
    }
    public static void processarPessoa(String operacao) throws IOException{
        try (Socket conn = new Socket(SERVER_IP, SERVER_PORT);
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            PrintWriter writer = new PrintWriter(conn.getOutputStream(), true)) {
            BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
            String mensagem = operacao;
            if (operacao.equalsIgnoreCase("INSERT")) {
                System.out.println("Digite CPF, Nome e Endereço separados por ponto e vírgula:");
                mensagem += ";" + teclado.readLine();
                System.out.println("Digite 'Vendedor' ou 'Cliente':");
                mensagem += ";" + teclado.readLine();
            }else if (operacao.equalsIgnoreCase("GET") || operacao.equalsIgnoreCase("DELETE")) {
                System.out.println("Digite o CPF:");
                mensagem += ";" + teclado.readLine();
            }else if (operacao.equalsIgnoreCase("UPDATE")) {
                System.out.println("Digite CPF, Novo Nome e Novo Endereço separados por ponto e vírgula:");
                mensagem += ";" + teclado.readLine();
            }

           writer.println(mensagem);
           
           String resposta;
                while ((resposta = reader.readLine()) != null) {
                    if (operacao.equalsIgnoreCase("LIST")){ 
                        System.out.println(resposta);
                        int qtd = Integer.parseInt(resposta);
                        for (int i = 0; i < qtd; i++) {
                            String pessoa = reader.readLine();
                            System.out.println(pessoa);
                        }
                    }else {
                        System.out.println(resposta);
                    }
                    break;
                }
           conn.close();
        
        } catch (IOException e) {
            e.printStackTrace();   
        }
    }
    
    public static void processarPedido(String operacao) throws IOException{
        try (Socket conn = new Socket(SERVER_IP, SERVER_PORT);
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            PrintWriter writer = new PrintWriter(conn.getOutputStream(), true)) {
            BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
            String mensagem = operacao;
            if (operacao.equalsIgnoreCase("INSERT_PEDIDO")) {
                System.out.println("Digite o CPF do Cliente:");
                mensagem += ";" + teclado.readLine();
                System.out.println("Digite as descrições dos produtos separados por ponto e vírgula:");
                mensagem += ";" + teclado.readLine();
            }else if (operacao.equalsIgnoreCase("GET_PEDIDO")) {
                System.out.println("Digite seu CPF:");
                mensagem += ";" + teclado.readLine();
            }
            
           writer.println(mensagem);
           
           String resposta;
                while ((resposta = reader.readLine()) != null) {
                    if (operacao.equalsIgnoreCase("LIST_PEDIDO") || operacao.equalsIgnoreCase("GET_PEDIDO")){ 
                        System.out.println(resposta);
                        int qtd = Integer.parseInt(resposta);
                        for (int i = 0; i < qtd; i++) {
                            String pedido = reader.readLine();
                            System.out.println(pedido);
                        }
                    }else {
                        System.out.println(resposta);
                    }
                    break;
                }
           conn.close();
        
        } catch (IOException e) {
            e.printStackTrace();   
        }
    }
    
    public static void processarProduto(String operacao) throws IOException{
        try (Socket conn = new Socket(SERVER_IP, SERVER_PORT);
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            PrintWriter writer = new PrintWriter(conn.getOutputStream(), true)) {
            BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
            String mensagem = operacao;
            if (operacao.equalsIgnoreCase("INSERT_PRODUTO")) {
                System.out.println("Digite seu CPF para autenticação:");
                mensagem += ";" + teclado.readLine();
                System.out.println("Digite ID, Descrição e Valor do Produto separados por ponto e vírgula:");
                mensagem += ";" + teclado.readLine();
            }else if (operacao.equalsIgnoreCase("GET_PRODUTO")) {
                System.out.println("Digite seu CPF para autenticação:");
                mensagem += ";" + teclado.readLine();
                System.out.println("Digite o ID do Produto:");
                mensagem += ";" + teclado.readLine();
            } else if (operacao.equalsIgnoreCase("UPDATE_PRODUTO")) {
                System.out.println("Digite seu CPF para autenticação:");
                mensagem += ";" + teclado.readLine();
                System.out.println("Digite ID do Produto, Nova Descrição e Novo Valor separados por ponto e vírgula:");
                mensagem += ";" + teclado.readLine();
            }else if (operacao.equalsIgnoreCase("DELETE_PRODUTO")) {
                System.out.println("Digite seu CPF para autenticação:");
                mensagem += ";" + teclado.readLine();
                System.out.println("Digite o ID do Produto:");
                mensagem += ";" + teclado.readLine();
            }
            
           writer.println(mensagem);
           
           String resposta;
                while ((resposta = reader.readLine()) != null) {
                    if (operacao.equalsIgnoreCase("LIST_PRODUTO")){ 
                        System.out.println(resposta);
                        int qtd = Integer.parseInt(resposta);
                        for (int i = 0; i < qtd; i++) {
                            String produto = reader.readLine();
                            System.out.println(produto);
                        }
                    }else {
                        System.out.println(resposta);
                    }
                    break;
                }
           conn.close();
        
        } catch (IOException e) {
            e.printStackTrace();   
        }
    }
}